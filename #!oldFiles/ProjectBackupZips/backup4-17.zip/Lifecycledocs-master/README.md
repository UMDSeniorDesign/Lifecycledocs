LifecycleDocs
=============
Senior Design Project #3

Jeremiah Butler,
Peter Magalhaes,
Kevin Palmer,
Aria Ushani

end
