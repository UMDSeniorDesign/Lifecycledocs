
function checkCookie(value) {
	sessvars.value = value;
	//alert(document.cookie);
	/*var val = value + "=";
	var y = document.cookie.split(';');
	
	for(var i = 0; i < y.length; i++) {
		var x = y[i];
		 alert(x);
		if(x.indexOf(value) == 0)
			return x.substring(val.length, x.length);
	}
	*/
}